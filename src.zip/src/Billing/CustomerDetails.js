export function CustomerDetails({
  customerBilling,
  setSelectCustomer,
  selectCustomer,
  setCustomerBilling,
  isPopupOpen,
  setPopupOpen,
}) {
  function openPopup() {
    setPopupOpen(true);
    setSelectCustomer(true);
    setCustomerBilling(false);
  }
  return <>{customerBilling && <CustomerBilling onAdd={openPopup} />}</>;
}
function CustomerBilling({ onAdd }) {
  return (
    <div className="body">
      <h1 className="master">Billing</h1>
      <div className="customer-container">
        <h3 className="details">Coustumer Details</h3>

        <hr />
        <div className=" center-add">
          <div className="Add-btn" onClick={onAdd}>
            +ADD
          </div>
        </div>
      </div>
    </div>
  );
}
